
d=load('tmcmc.txt'); 

%%


plotmatrix_hist(d(:,1:end-1))