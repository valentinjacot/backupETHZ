#include "model/grass.hpp"
#include "korali.h"

#define MM 80.0
#define PH 6.0

int main(int argc, char* argv[])
{

	return 0;
}
