A = importdata('tmcmc.txt');
plotmatrix_hist(A(:,1:end-1));
