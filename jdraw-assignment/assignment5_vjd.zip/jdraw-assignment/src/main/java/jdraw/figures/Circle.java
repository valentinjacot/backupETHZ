package jdraw.figures;

import java.awt.Color;
import java.awt.Graphics;

public class Circle extends AbstractRectangularFigure{

	public Circle(int x, int y, int w, int h) {
		super(x, y, w, w);
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(Color.WHITE);
		g.fillOval(rectangle.x, rectangle.y, rectangle.width, rectangle.width);
		g.setColor(Color.BLACK);
		g.drawOval(rectangle.x, rectangle.y, rectangle.width, rectangle.width);		
	}

}
