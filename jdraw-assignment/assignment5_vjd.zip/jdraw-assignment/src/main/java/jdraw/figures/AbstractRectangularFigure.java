package jdraw.figures;

import java.awt.Point;
import java.awt.Rectangle;

public abstract class AbstractRectangularFigure extends AbstractFigure{
	protected final Rectangle rectangle;

	
	public AbstractRectangularFigure(int x, int y, int w, int h) {
		rectangle = new Rectangle(x, y, w, h);
	}

	@Override
	public void setBounds(Point origin, Point corner) {
		if( origin != rectangle.getLocation()) {
			rectangle.setFrameFromDiagonal(origin, corner);
			notifyFListeners();
		}
	}

	@Override
	public void move(int dx, int dy) {
		if( dx!=0 || dy!=0) {
			rectangle.setLocation(rectangle.x + dx, rectangle.y + dy);
			notifyFListeners();
		}
	}

	@Override
	public Rectangle getBounds() {
		return rectangle.getBounds();
	}
	
	@Override
	public boolean contains(int x, int y) {
		return rectangle.contains(x, y);
	}

}
